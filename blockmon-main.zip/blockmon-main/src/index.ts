import { MainApplication } from "./MainApplication";

const app = new MainApplication();
app.start()